A friend function is a function that helps an another function in making a task.

Friend function can access the public and private and protected things in the class.

Example :

![[Pasted image 20250811112237.png]]

Practical code :

```

```

