Friend classes can access the features of each other.

How to create a friend class :

![[Pasted image 20250811170714.png]]

Practical code : 

```
#include <iostream>

using namespace std;

  

class alpha

{

private:

int a;

public:

alpha (int arg = 0)

{

a = arg;

}

  

friend class beta;

};

  

class beta

{

private:

int b;

public:

beta (int arg = 0)

{

b = arg;

}

  

int sum ()

{

alpha a(6);

  

int sum = a.a + b;

  

return sum;

}

};

  

int main()

{

beta b(5);

  

cout << "The sum is " << b.sum() ;

return 0;

}
```