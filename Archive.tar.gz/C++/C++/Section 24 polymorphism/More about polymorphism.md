The function that exist in more than one form is called polymorphism.

![[Pasted image 20250810192337.png]]

Types of poly morphism :

![[Pasted image 20250810192526.png]]

