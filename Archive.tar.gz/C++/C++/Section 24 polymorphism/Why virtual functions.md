![[Pasted image 20250810190725.png]]

We use virtual functions when we do not know witch function or object will come next.