![[Pasted image 20250810191740.png]]

