Problem :

![[Pasted image 20250811103552.png]]Solution :

![[Pasted image 20250811104151.png]]

Practical code :

```
**#include <iostream>

using namespace std;

  

class base

{

public:

virtual ~base()

{

cout << "Base class." << endl;

}

};

  

class drived:public base

{

public:

~drived()

{

cout << "Drived class." << endl;

}

};

  

int main()

{

base *ptr;

  

ptr = new drived;

  

delete ptr;

return 0;

}
``` 