The definition :
	![[Pasted image 20250810181747.png]]
The practical meaning :
	![[Pasted image 20250810181910.png]]

Virtual functions allows us to use the functions for the drived classes.