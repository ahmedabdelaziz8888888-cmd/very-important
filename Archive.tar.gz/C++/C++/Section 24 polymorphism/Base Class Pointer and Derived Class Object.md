
If we make a pointer of the base calls it can't access the features of the drived class even if it had a drived class object in it.