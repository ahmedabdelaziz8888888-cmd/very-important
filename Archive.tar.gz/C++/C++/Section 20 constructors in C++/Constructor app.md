
An app to take the phone details like :

1 - Ram
2 - Name
3 - Processor
4 - Battery

Project steps :

1 - Include the needed libraries.
[[Libraries for the constructor app]].
2 - Create a class.
[[Class for the constructor application]].
3 - Make the main function.
[[The main function for the constructor application]].
