We use the constructors to reduce the compiling time and reduce the use of functions and make the code simpler.

To write constructors there are some rules like :
1 - Constructors must have the same name as the class name.
2 - The constructor can not have a return type.
[[Constructor types]].