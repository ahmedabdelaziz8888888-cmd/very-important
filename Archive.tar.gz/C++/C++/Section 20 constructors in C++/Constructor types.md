There are three types of constructors :

1 - NON-Parametrized constructor and it is called default constructor.
[[Default constructor]].
2 - Parametrized constructor.
[[Parametrized constructor]].
3 - Copy constructor.
[[Copy constructor]].