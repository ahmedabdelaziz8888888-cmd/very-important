
The used class with its constructors and functions : 

```
class mobile
{
private:
	string Name;
	int Ram;
	string Processor;
	int Battery;
public:

	mobile(string Name_A = "Null", int Ram_A = 0, string Processor_A = "Null", int Battery_A = 0)
	{
		Name = Name_A;
		Ram = Ram_A;
		Processor = Processor_A;
		Battery = Battery_A;
	}

	mobile(mobile& mob)
	{
		Name = mob.Name;
		Ram = mob.Ram;
		Processor = mob.Processor;
		Battery = mob.Battery;
	}

	void Get_Mobile_Data();
};

void mobile::Get_Mobile_Data()
{
	cout << endl << "Name : " << Name;
	cout << endl << "Ram : " << Ram;
	cout << endl << "Processor : " << Processor;
	cout << endl << "Battery : " << Battery;
}

```