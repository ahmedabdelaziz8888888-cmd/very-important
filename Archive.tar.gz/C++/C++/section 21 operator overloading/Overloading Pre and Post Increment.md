
We cant use pre and post increment with pre defined objects by the user so we use overloading. 

Example :

![[overloading 2.PNG]]

Practical code :

```
#include <iostream>
#include <string>
using namespace std;

class person
{
private:
	int weight;
public:
	person(int w = 0)
	{
		weight = w;
	}

	void Print_weight()
	{
		cout << endl << "The weight is " << weight;
	}

	void operator ++()
	{
		++weight;
	}
	
	void operator ++(int)
	{
		++weight;
	}
};

int main()
{
	person jhon(78);
	++jhon;
	jhon++;
	jhon.Print_weight();
	
	return 0;
}
```