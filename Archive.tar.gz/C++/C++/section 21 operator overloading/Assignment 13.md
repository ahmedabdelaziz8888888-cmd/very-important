
The main code :

```
#include <iostream>
using namespace std;

class the_number
{
private:
	int num;
public:
	the_number(int num_A = 0)
	{
		num = num_A;
	}

	void Get_Number()
	{
		cout << endl << "The number is " << num;
	}

	void operator -- ()
	{
		--num;
	}

	void operator -- (int)
	{
		num--;
	}
};

int main()
{
	the_number num1(50);
	
	--num1;
	num1--;

	num1.Get_Number();

	return 0;
}
```