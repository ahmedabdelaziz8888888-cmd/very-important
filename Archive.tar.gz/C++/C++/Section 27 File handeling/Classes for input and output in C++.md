![[Pasted image 20250814165329.png]]

