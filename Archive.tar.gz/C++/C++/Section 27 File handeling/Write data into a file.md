1 - Create a stream.
	![[Pasted image 20250816210350.png]]
	![[Pasted image 20250816210522.png]]

2 - Save 
	![[Pasted image 20250816210711.png]]

Practical code :

```
#include <iostream>

#include <fstream>

using namespace std;

  

int main()

{

ofstream fout;

  

fout.open("my file.txt");

  

fout << "Ahmed \n abdelaziz";

  

fout.close();

  

return 0;

}
```