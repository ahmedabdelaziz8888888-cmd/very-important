Streams are paths for data to come in and out.

Picture : 
![[Pasted image 20250814164921.png]]

