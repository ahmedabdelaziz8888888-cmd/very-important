Tellp point where is the pointer when writing data to a file.

![[Pasted image 20250817172614.png]]
Practical code :

```

```