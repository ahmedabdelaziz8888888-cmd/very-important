To read the data from a file we will first make a stream to take the data then we will open the file into the ram then we will use this syntax in the photo to read the data character by character :

![[Pasted image 20250817162810.png]]