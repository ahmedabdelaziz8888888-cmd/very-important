About the destructor :

![[Pasted image 20250810125518.png]]

