
1 - Uninitialized pointer witch contains garbage memory.
2 - Memory leaks when we do not delete the pointer witch cause crashes.
3 - Dangling pointer when we have 2 pointers pointing on the same block of memory then we delete one of them the other one if used will cause crashes because the memory is not allocated and not initialized.