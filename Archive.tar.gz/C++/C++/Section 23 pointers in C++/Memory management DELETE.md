
Delete is used to remove the allocation of the dynamically allocated memory.

![[Pasted image 20250810102209.png]]


