
Memory management is to manage the memory for your app to run smooth and fast .

Example :

```

Memory management is to manage the memory for your app to run smooth and fast .

Example :

#include <iostream>  
using namespace  std;  
  
class test {  
private:  
    int *num;  
public:  
    test() {  
        num = new int;  
        *num = 5;  
        cout << *num << endl;  
    }  
  
    ~test() {  
        delete num;  
        cout << "Memory cleared!";  
    }  
};  
  
int main() {  
    test t;  
  
    return 0;  
}
```