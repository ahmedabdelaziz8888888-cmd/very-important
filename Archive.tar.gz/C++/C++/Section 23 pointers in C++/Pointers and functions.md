
Some pictures from the lecture :

![[Pointers and functions.png]]

