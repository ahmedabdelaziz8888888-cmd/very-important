
In this lecture we used new in a practical code :

```
#include <iostream>

using namespace std;

  

class test

{

private:

int data;

public:

void set_data(int set)

{

data = set;

}

  

int get_data()

{

return data;

}

};

  

int main()

{

test *ptr = new test;

  

ptr->set_data(10);

  

cout << endl << ptr->get_data();

return 0;

}
```