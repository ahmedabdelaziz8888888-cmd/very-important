
Pointers are special variables that point to a place in the memory.

Pointers store memory addresses.

Next note [[Why are pointers used?]].

