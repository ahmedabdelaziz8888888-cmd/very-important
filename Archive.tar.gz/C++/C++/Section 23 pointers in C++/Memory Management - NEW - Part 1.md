There are two ways to allocate memory in C++ :

1 - Static memory allocation :
	We use static memory allocation when we know the upper limit of the memory that will be used.
2 - Dynamic memory allocation :
	We use Dynamic memory allocation when we don't know the upper limit of the memory used.

![[Pasted image 20250809131430.png]]

Using New 

![[Pasted image 20250809183809.png]]

![[Pasted image 20250809184135.png]]

