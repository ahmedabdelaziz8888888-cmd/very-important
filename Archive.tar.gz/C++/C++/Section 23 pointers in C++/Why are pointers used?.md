
This picture shows the reason :

![[why pointers.png]]

Pointers are used to :

1 - Directly access the memory.
2 - Access array elements.
3 - Passing arrays to functions.
4 - Creating data structures like linked lists.

![[pointer use.png]]

Next lecture [[Program in Memory]].