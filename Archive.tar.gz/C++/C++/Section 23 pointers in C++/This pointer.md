![[Pasted image 20250810112136.png]]

The practical code :

```
#include <iostream>

#include <string>

using namespace std;

  

class person

{

private:

string name;

  

int age;

public:

person (string name , int age)

{

this->age = age;

this->name = name;

}

  

void print()

{

cout << "The name is " << name << endl;

cout << "The age is " << age;

}

};

  

int main()

{

person p("Ahmed" , 30);

  

p.print();

return 0;

}
```