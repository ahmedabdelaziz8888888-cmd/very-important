
Inheritance is giving the properties of one object to an another object.

Some pictures form the lecture :

![[inhertance.PNG]]

