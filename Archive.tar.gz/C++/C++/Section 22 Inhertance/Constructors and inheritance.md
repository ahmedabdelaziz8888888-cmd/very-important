
![[Constructors & inheritance.PNG]]

In derived d2(9); an error will appear.

Code : 

```
#include <iostream>
using namespace std;

class base
{
public:
	base()
	{
		cout << "This is the default constructor of thr base class.";
	}

	base(int b )
	{
		cout << "this is the prametrized constructor of the base class. And this is a number : " << b;
	}
};

class drived : public base
{
	//Empty
};

int main()
{
	drived b;

	// If we use drived b(9); we get an error becouse it onely has acees on the default constructor.
	
	return 0;
}
```