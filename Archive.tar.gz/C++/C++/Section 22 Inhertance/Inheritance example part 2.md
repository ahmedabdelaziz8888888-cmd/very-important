While following along with the instructor the wi-fi connection was gone and I completed the code in my own.

Code :

```
#include <iostream>
using namespace std;

class rectangle
{
public:
	int length;
	int breadth;

	void Area()
	{
		cout << "The area of the rectangle is" << length * breadth;
	}
};

class cuboid : public rectangle
{
public:
	int hight;

	void volium(int x , int y , int z)
	{
		length = x;
		breadth = y;
		hight = z;
		cout << "The volium of the cuboid is " << length * breadth * hight;
	}
};

int main()
{
	cuboid c;

	//my code

	c.volium(15 , 15 , 15);
}


//Added the int x and int y and int and int z.
```

Here is what did the instructor did in his program :

![[Instructor's example.PNG]]

![[Instructor's example 2.PNG]]