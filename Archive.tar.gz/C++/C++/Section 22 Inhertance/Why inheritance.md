
We use inheritance to reduce the duplicated code.
We use inheritance for code reusability.
We use inheritance to make better organization of our code.