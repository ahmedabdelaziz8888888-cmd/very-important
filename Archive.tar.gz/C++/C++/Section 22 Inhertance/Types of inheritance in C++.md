
In the C++ language there are many types of inheritance such as :
	1 - [[Simple inheritance]].
	2 - [[Multi level inheritance]].
	3 - [[Hierarchical inheritance]].
	4 - [[Multiple inheritance]].
	5 - [[Multi path inheritance]].