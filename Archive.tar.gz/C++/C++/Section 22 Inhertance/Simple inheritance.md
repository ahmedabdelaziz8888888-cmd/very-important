
It means that one class is inheriting an another class (Simple and easy). 