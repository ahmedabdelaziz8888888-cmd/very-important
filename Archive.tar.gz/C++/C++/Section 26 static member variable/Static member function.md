Static member functions can only access static member functions.
