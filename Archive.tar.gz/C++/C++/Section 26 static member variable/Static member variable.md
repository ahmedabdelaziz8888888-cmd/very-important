![[Pasted image 20250811195522.png]]

static memory does not equip the memory multiple times.

notes :

![[Pasted image 20250811200420.png]]

printing the static data :

![[Pasted image 20250811220230.png]]

Practical code : 

```
#include <iostream>

using namespace std;

  

class alpha

{

private:

int a;

int b;

public:

alpha()

{

a = 5;

b = 5;

  

stat++;

}

  

static int stat;

};

  

int alpha::stat = 0;

  

int main ()

{

alpha a1;

alpha a2;

alpha a3;

  

cout << "Value using a1 :" <<a1.stat << endl;

cout << "Value using a2 :" <<a2.stat << endl;

cout << "Value using alpha :" <<alpha::stat << endl;

return 0;

}
```

