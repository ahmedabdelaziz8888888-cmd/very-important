#include <iostream>
using namespace std;

class car
{
private:
    int weight;
public:
    void set_weight(int w)
    {
        weight = w;
    }

    int get_weight()
    {
        return weight;
    }   
};

class BMW
{
private:
    int top_speed;
    car *ptr;
public:
    BMW(int weight , int T_speed)
    {
        ptr = new car;
        ptr->set_weight(weight);

        top_speed = T_speed;
    }

    int get_weight()
    {
        return ptr->get_weight();
    }

    int get_top_speed()
    {
        return top_speed;
    }

    ~BMW()
    {
        delete ptr;
    }
};

int main()
{
    BMW b(3000 , 300);

    cout << "The weight of the car is " << b.get_weight() << endl;

    cout << "The top speed of the car is " << b.get_top_speed() << endl;
    
    return 0;
}