#include <iostream>
using namespace std;

class test
{
public:
    test ()
    {
        cout << "This is a constructor" << endl;
    }

    ~test()
    {
        cout<<"This is a destructor";
    }
};