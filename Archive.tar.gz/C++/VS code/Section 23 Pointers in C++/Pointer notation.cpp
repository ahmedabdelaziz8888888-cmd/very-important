#include <iostream>
using namespace std;

int main()
{
    int number = 10;

    int *ptr = NULL;

    ptr = &number;

    cout << "Ptr : " << ptr << endl;

    cout << "*Ptr : " << *ptr << endl;

    return 0;
}