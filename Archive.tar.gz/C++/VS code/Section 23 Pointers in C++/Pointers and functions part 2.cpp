#include <iostream>
using namespace std;

void print(int *ptr);

const int MAX = 5;

int main ()
{
    
    int arr[MAX] = {10,20,30,40,50};
    
    print (arr);

    return 0;
}

void print(int *ptr)
{
    for (int i = 0 ; i < MAX ; i++)
    {
        cout << endl << *ptr++;
    }
}