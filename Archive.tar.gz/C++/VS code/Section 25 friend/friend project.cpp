#include <iostream>
using namespace std;

class person
{
private:
    int weight;
public:
    person (int w = 0)
    {
        weight = w;
    }

    friend bool operator<(person x , person y);
    friend bool operator>(person x , person y);
};

bool operator > (person x , person y)
{
    return x.weight > y.weight;
}

bool operator < (person x , person y)
{
    return x.weight < y.weight;
}

int main()
{

    int w1;
    int w2;

    cout << "Enter the weight of jhon : " ;
    cin >> w1;

    cout << "Enter the weight of andrew : " ;
    cin >> w2;

    person jhon(w1);
    person andrew(w2);

    if (jhon > andrew)
    {
        cout << "Jhon is heavier.";
    }
    
    if (jhon < andrew)
    {
        cout << "Andrew is heavier.";
    }

    return 0;
}