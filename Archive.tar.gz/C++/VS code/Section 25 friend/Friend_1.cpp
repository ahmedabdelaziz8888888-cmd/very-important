#include <iostream>
using namespace std;

class alpha
{
private:
    int a;
public:
    alpha (int arg = 0)
    {
        a = arg;
    }

    friend void fun();
};

class beta 
{
private:
    int b;
public:
    beta (int arg = 0)
    {
        b = arg;
    }

    friend void fun();
};

void fun ()
{
    alpha a(5);
    beta b(5);

    int x = a.a + b.b;

    cout << "Sum = " << x;
}  

int main ()
{
    fun();
    
    return 0;
}