#include <iostream>
using namespace std;

class alpha
{
private:
    int a;
    int b;
public:

    

    alpha()
    {
        a = 5;
        b = 5;

        stat++;
    }
    static int stat;
   
    

    static int getstatic()
    {
        stat++;
        return stat;
    }
};

int alpha::stat = -1;

int main ()
{
    alpha a1;


    cout << "Value using a1 :" <<a1.getstatic() << endl;
    cout << "Value using alpha :" <<alpha::getstatic() << endl;
    
    return 0;
}