#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ofstream fout;
    int pos;

    fout.open("tellp.txt" , ios::app);

    pos = fout.tellp();

    cout << "Put  pointer is at " << pos << endl;

    fout << "Ahmed" << endl;

    pos = fout.tellp();
    cout << "Put  pointer is at " << pos << endl;

    fout.close();

    return 0;
}