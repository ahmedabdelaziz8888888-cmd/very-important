#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ofstream fout;

    fout.open("my file.txt");

    fout << "Ahmed \n abdelaziz";

    fout.close();

    return 0;
}