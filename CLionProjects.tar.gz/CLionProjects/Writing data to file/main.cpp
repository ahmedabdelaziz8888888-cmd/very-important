#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ifstream ifn;
    char ch;

    ifn.open("my file.txt");
    ifn >> ch;

    while (!ifn.eof())
    {
        cout << ch;
        ifn >> ch;
    }


    return 0;
}